import React, { useState } from 'react';

const Form = (props) =>{
    let {name, setName} = props;

    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [error, setError] = useState("");




    const submitHandler = (e) => {
        e.preventDefault();

        if(firstName.length < 2){
            setError("First name must be more than 2 characters")
        }
        if(lastName.length < 2){
            setError("Last name must be more than 2 characters")
        }
        if(email.length < 2){
            setError("Email must be more than 2 characters")
        }
        if(password.length != confirmPassword.length){
            setError("Passwords must match")
        }
    }


    return(
        <div>
            <p>{error}</p>
            <form onSubmit={submitHandler}>
                <br />
                <input type="text" value={firstName} onChange={e => setFirstName(e.target.value)}/>
                <br />
                <input type="text" value={lastName} onChange={e => setLastName(e.target.value)}/>
                <br />
                <input type="text" value={email} onChange={e => setEmail(e.target.value)}/>
                <br />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)}/>
                <br />
                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)}/>
                <br />
                <input type="submit" value={`Change ${name}'s name`}/>
            </form>
        </div>
    );
};
export default Form;