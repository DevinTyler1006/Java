import React from 'react';
import './App.css';

import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard firstname = {"Devin"} lastname = {"Tyler"} age = {26} haircolor = {"Brown"}/>
      <PersonCard firstname = {"Jon"} lastname = {"Howry"} age = {26} haircolor = {"Blonde"}/>
      <PersonCard firstname = {"James"} lastname = {"Bryant"} age = {25} haircolor = {"Blondish"}/>
    </div>
  );
}

export default App;
