import React, { Component } from 'react';

class PersonCard extends Component{
    render(){
        return(
            <div>
                {this.props.someInfo}
            </div>
        );
    }
}

export default PersonCard