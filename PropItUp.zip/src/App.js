import React from 'react';
import './App.css';

import MyNewComponent from './components/MyNewComponent';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <h1>Doe, Jane</h1>
      <PersonCard someInfo={"Age: 45"}/>
      <PersonCard someInfo={"Hair Color: Black"}/>
      <h1>Smith, Jon</h1>
      <PersonCard someInfo={"Age: 88"}/>
      <PersonCard someInfo={"Hair Color: Brown"}/>
      <h1>Fillmore, Millard</h1>
      <PersonCard someInfo={"Age: 50"}/>
      <PersonCard someInfo={"Hair Color: Brown"}/>
      <h1>Smith, Maria</h1>
      <PersonCard someInfo={"Age: 50"}/>
      <PersonCard someInfo={"Hair Color: Brown"}/>
    </div>
  );
}

export default App;
